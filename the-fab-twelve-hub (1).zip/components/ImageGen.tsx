import React, { useState } from 'react';
import { Image, Layers, Aperture, Download, Loader2 } from 'lucide-react';
import { generateLeagueImage } from '../services/gemini';

const ASPECT_RATIOS = ["1:1", "4:3", "3:4", "16:9", "9:16"];
const SIZES = ["1K", "2K", "4K"];

const ImageGen: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [ratio, setRatio] = useState('1:1');
    const [size, setSize] = useState('1K');
    const [image, setImage] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const handleGenerate = async () => {
        if (!prompt) return;
        setLoading(true);
        try {
            const img = await generateLeagueImage(prompt, ratio, size);
            setImage(img);
        } catch (e) {
            alert("Error generating image");
        }
        setLoading(false);
    };

    return (
        <div className="fade-in-up w-full max-w-4xl mx-auto">
             <h2 className="text-2xl font-black text-white italic mb-6 border-l-4 border-purple-500 pl-4 uppercase flex items-center">
                <Image className="mr-2 text-purple-500" /> Arena Art Studio
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6 bg-slate-900/80 p-6 rounded-2xl border border-slate-700">
                    <div>
                        <label className="block text-xs font-bold text-purple-400 uppercase mb-2">Prompt Creativo</label>
                        <textarea 
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Ej: Un logo futurista para un equipo llamado 'Los Titanes', colores neon azul y plata, estilo cyberpunk..."
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:border-purple-500 focus:outline-none h-32 resize-none"
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                             <label className="block text-xs font-bold text-gray-400 uppercase mb-2 flex items-center"><Layers size={14} className="mr-1"/> Aspect Ratio</label>
                             <div className="grid grid-cols-3 gap-2">
                                {ASPECT_RATIOS.map(r => (
                                    <button 
                                        key={r}
                                        onClick={() => setRatio(r)}
                                        className={`text-xs font-mono py-2 rounded border ${ratio === r ? 'bg-purple-600 border-purple-400 text-white' : 'bg-slate-800 border-slate-700 text-gray-400 hover:bg-slate-700'}`}
                                    >
                                        {r}
                                    </button>
                                ))}
                             </div>
                        </div>
                        <div>
                             <label className="block text-xs font-bold text-gray-400 uppercase mb-2 flex items-center"><Aperture size={14} className="mr-1"/> Resolución</label>
                             <div className="grid grid-cols-3 gap-2">
                                {SIZES.map(s => (
                                    <button 
                                        key={s}
                                        onClick={() => setSize(s)}
                                        className={`text-xs font-mono py-2 rounded border ${size === s ? 'bg-purple-600 border-purple-400 text-white' : 'bg-slate-800 border-slate-700 text-gray-400 hover:bg-slate-700'}`}
                                    >
                                        {s}
                                    </button>
                                ))}
                             </div>
                        </div>
                    </div>

                    <button 
                        onClick={handleGenerate}
                        disabled={loading || !prompt}
                        className="w-full py-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black uppercase tracking-widest rounded-xl shadow-lg shadow-purple-900/20 disabled:opacity-50 transition-all transform active:scale-95 flex items-center justify-center"
                    >
                        {loading ? <><Loader2 className="animate-spin mr-2"/> Generando Arte...</> : "Generar Imagen"}
                    </button>
                </div>

                <div className="bg-black rounded-2xl border border-slate-800 flex items-center justify-center relative overflow-hidden min-h-[400px]">
                    <div className="absolute inset-0 bg-[linear-gradient(45deg,#0f172a_25%,transparent_25%,transparent_75%,#0f172a_75%,#0f172a),linear-gradient(45deg,#0f172a_25%,transparent_25%,transparent_75%,#0f172a_75%,#0f172a)] bg-[length:20px_20px] bg-[position:0_0,10px_10px] opacity-20"></div>
                    
                    {image ? (
                        <div className="relative group w-full h-full flex items-center justify-center">
                            <img src={image} alt="Generated" className="max-w-full max-h-full object-contain shadow-2xl" />
                            <a 
                                href={image} 
                                download="fab-twelve-art.png"
                                className="absolute bottom-4 right-4 bg-white/10 backdrop-blur text-white p-2 rounded-full hover:bg-white/20 transition-all opacity-0 group-hover:opacity-100"
                            >
                                <Download size={20} />
                            </a>
                        </div>
                    ) : (
                        <div className="text-center text-slate-600 p-8">
                            <Image size={64} className="mx-auto mb-4 opacity-20" />
                            <p className="uppercase font-bold text-sm tracking-widest">El lienzo está vacío</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ImageGen;