import React, { useState, useEffect } from 'react';

interface Props {
  value: string;
  duration?: number;
  className?: string;
}

const CountUp: React.FC<Props> = ({ value, duration = 2000, className = "" }) => {
  const [displayValue, setDisplayValue] = useState("0");

  useEffect(() => {
    // Regex to find the number in the string (integers or decimals, positive or negative)
    const match = value.match(/([-+]?[0-9]*\.?[0-9]+)/);
    
    if (!match) {
      setDisplayValue(value);
      return;
    }

    const originalNumber = parseFloat(match[0]);
    const prefix = value.substring(0, match.index);
    const suffix = value.substring((match.index || 0) + match[0].length);
    const isDecimal = match[0].includes('.');
    const decimals = isDecimal ? match[0].split('.')[1].length : 0;

    let startTime: number | null = null;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);
      
      // EaseOutQuart function for smooth landing
      const ease = 1 - Math.pow(1 - percentage, 4);
      
      const currentNumber = originalNumber * ease;
      
      const formattedNumber = currentNumber.toFixed(decimals);
      setDisplayValue(`${prefix}${formattedNumber}${suffix}`);

      if (percentage < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);

  }, [value, duration]);

  return <span className={className}>{displayValue}</span>;
};

export default CountUp;