import React, { useEffect, useState } from 'react';
import { Crown } from 'lucide-react';

interface Props {
  value: number;
  max: number;
  color?: string;
  label: string;
  isLeader?: boolean;
}

const StatBar: React.FC<Props> = ({ value, max, color = "bg-blue-500", label, isLeader = false }) => {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    // Small delay to ensure the transition triggers after render
    const timer = setTimeout(() => {
        const pct = (value / max) * 100;
        setWidth(pct);
    }, 100);
    return () => clearTimeout(timer);
  }, [value, max]);

  return (
    <div className="w-full mb-1 relative">
      <div className="flex justify-between text-xs uppercase font-bold text-gray-400 mb-0.5">
        <span>{label}</span>
        <div className="flex items-center relative">
            <span className={`text-white font-mono ${isLeader ? 'text-yellow-400 scale-110 transition-transform' : ''}`}>{value}</span>
            {isLeader && (
              <Crown 
                  size={14} 
                  className="absolute -top-4 -right-2 text-yellow-400 fill-yellow-400 animate-pulse drop-shadow-[0_0_5px_rgba(250,204,21,0.8)]" 
                  strokeWidth={2.5}
              />
            )}
        </div>
      </div>
      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
        <div 
          className={`h-full ${color} shadow-[0_0_10px_currentColor] transition-all duration-1000 ease-in`} 
          style={{ width: `${width}%` }}
        ></div>
      </div>
    </div>
  );
};

export default StatBar;