import React, { useState } from 'react';
import { Mic, MicOff, Volume2, Radio } from 'lucide-react';
import { connectLiveSession } from '../services/gemini';

const LiveAnnouncer: React.FC = () => {
    const [isLive, setIsLive] = useState(false);
    const [status, setStatus] = useState("Offline");
    const [disconnectFn, setDisconnectFn] = useState<(() => void) | null>(null);

    const toggleLive = async () => {
        if (isLive && disconnectFn) {
            disconnectFn();
            setDisconnectFn(null);
            setIsLive(false);
            setStatus("Offline");
        } else {
            const session = await connectLiveSession(
                (buffer) => {
                    // Visualizer hook could go here
                },
                (s) => setStatus(s)
            );
            if (session) {
                setDisconnectFn(() => session.disconnect);
                setIsLive(true);
            }
        }
    };

    return (
        <div className="fixed bottom-24 right-4 z-50 flex flex-col space-y-2 items-end">
            <div className={`transition-all duration-500 overflow-hidden ${isLive ? 'max-h-20 opacity-100' : 'max-h-0 opacity-0'}`}>
                <div className="bg-slate-900 border border-red-500 rounded-lg p-3 shadow-2xl flex items-center space-x-3 mb-2">
                    <div className="relative w-3 h-3">
                        <div className="absolute w-full h-full bg-red-500 rounded-full animate-ping"></div>
                        <div className="absolute w-full h-full bg-red-500 rounded-full"></div>
                    </div>
                    <span className="text-red-500 font-bold uppercase text-xs tracking-wider animate-pulse">{status}</span>
                    <div className="h-4 w-20 bg-slate-800 rounded flex items-center justify-center overflow-hidden">
                         <div className="w-full h-1 bg-gradient-to-r from-green-500 to-red-500 animate-pulse"></div>
                    </div>
                </div>
            </div>

            <div className="flex space-x-2">
                <button 
                    onClick={toggleLive}
                    className={`${isLive ? 'bg-red-600 animate-pulse shadow-[0_0_20px_red]' : 'bg-slate-700 hover:bg-slate-600'} text-white p-4 rounded-full shadow-lg transition-all hover:scale-110 border-2 ${isLive ? 'border-red-400' : 'border-slate-500'}`}
                    title="Modo Comentarista en Vivo"
                >
                    {isLive ? <MicOff size={24} /> : <Mic size={24} />}
                </button>
            </div>
        </div>
    );
};

export default LiveAnnouncer;