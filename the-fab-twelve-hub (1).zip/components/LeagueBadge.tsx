import React, { ReactNode } from 'react';

interface Props {
  color: string;
  icon: ReactNode;
  size?: number;
}

const LeagueBadge: React.FC<Props> = ({ color, icon, size = 48 }) => (
  <div 
    className="relative flex items-center justify-center transform transition-transform duration-300 hover:scale-110 group shrink-0"
    style={{ width: size, height: size }}
  >
    <div 
      className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-50 transition-opacity duration-500 blur-lg"
      style={{ backgroundColor: color }}
    ></div>

    <div 
      className="relative w-full h-full rounded-full flex items-center justify-center bg-slate-900 overflow-hidden shadow-xl z-10"
      style={{ 
        border: `2px solid ${color}`, 
        boxShadow: `0 0 10px ${color}40, inset 0 0 15px ${color}40`
      }}
    >
      <div 
        className="absolute inset-0 opacity-40"
        style={{ background: `radial-gradient(circle at 50% 0%, ${color}, transparent 80%)` }}
      ></div>
      
      <div className="absolute top-0 left-0 w-full h-[40%] bg-gradient-to-b from-white/10 to-transparent rounded-t-full pointer-events-none"></div>
      
      <div className="relative z-10 text-white drop-shadow-md flex items-center justify-center">
        {icon}
      </div>
    </div>
  </div>
);

export default LeagueBadge;