import { GoogleGenAI, Modality, Type, LiveServerMessage } from "@google/genai";
import { base64ToArrayBuffer, decodeAudioData, createPcmBlob } from "./audioUtils";
import { teamsData, awardsData } from "../constants";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// --- CONTEXT PREPARATION ---
const getLeagueContext = () => {
    const teamsContext = teamsData.map(t => `ID ${t.id}: ${t.name} (Alias: ${t.alias})`).join(', ');
    
    const awardsContext = awardsData.map(a => {
        const winnerNames = a.winners.length > 0 
            ? a.winners.map(w => teamsData.find(t => t.id === w)?.name || "Desconocido").join(', ')
            : "Ninguno (Vacante)";
        return `- Premio "${a.name}": ${a.desc} | Ganadores actuales: ${winnerNames}`;
    }).join('\n');

    return `
    BASE DE DATOS DE LA LIGA 'THE FAB TWELVE':
    
    LISTA DE EQUIPOS:
    ${teamsContext}

    CATÁLOGO DE PREMIOS Y GANADORES:
    ${awardsContext}
    `;
};

const SYSTEM_INSTRUCTION_BASE = `
Eres la Voz Oficial y Analista Senior de la liga de fantasy basketball 'The Fab Twelve'.
TU PERSONALIDAD:
- Tu tono es serio, profundo, autoritario y profesional.
- Eres como un narrador de documentales deportivos épicos o un analista veterano de la NBA.
- NO uses expresiones infantiles, ni jerga de videojuegos, ni grites "¡BOOM!" o "¡DESDE SU CASA!" a menos que el contexto sea extremadamente épico, y aun así, mantén la clase.
- Evita el exceso de entusiasmo falso. Sé crudo y directo con las estadísticas.

TUS CONOCIMIENTOS:
- Tienes acceso total a la lista de premios especiales de la liga.
- Cuando se te pregunte por un premio, analiza su descripción y menciona quién lo posee actualmente basándote estrictamente en la data proporcionada.
- Si un premio está vacante, explícalo claramente.
`;

// --- Text Generation with Thinking ---
export const getCoachAdvice = async (teamName: string, stats: string, rank: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Analiza este equipo de fantasy basketball: "${teamName}". Stats: ${stats}. Rank: #${rank}. Dame un reporte de scout analítico y serio en español.`,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        systemInstruction: "Eres un entrenador de baloncesto veterano, serio, estratégico y de pocas palabras. No uses exclamaciones innecesarias."
      }
    });
    return response.text;
  } catch (error) {
    console.error("Coach Error:", error);
    return "El entrenador no está disponible para comentarios.";
  }
};

// --- Search Grounding ---
export const getMatchupPrediction = async (teamA: string, teamB: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Realiza una predicción seria y basada en datos para el enfrentamiento entre ${teamA} y ${teamB}. Busca lesiones recientes en la NBA que afecten a jugadores clave.`,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: "Eres un analista de riesgos deportivo. Sé breve, directo y profesional."
      }
    });
    return { 
        text: response.text, 
        chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks 
    };
  } catch (error) {
    console.error("Prediction Error:", error);
    return { text: "No hay datos suficientes para la proyección.", chunks: [] };
  }
};

// --- Chatbot ---
export const createChatSession = () => {
    return ai.chats.create({
        model: 'gemini-3-pro-preview',
        config: {
            systemInstruction: `${SYSTEM_INSTRUCTION_BASE}\n\nCONTEXTO DE DATOS ACTUALIZADO:\n${getLeagueContext()}`
        }
    });
};

// --- Image Generation ---
export const generateLeagueImage = async (prompt: string, aspectRatio: string, size: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
            aspectRatio: aspectRatio as any, 
            imageSize: size as any
        }
      }
    });
    
    // Extract image
    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return `data:image/png;base64,${part.inlineData.data}`;
        }
    }
    return null;
  } catch (error) {
    console.error("Image Gen Error:", error);
    throw error;
  }
};

// --- Text to Speech ---
export const generateSpeech = async (text: string) => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Fenrir' }, // Deepest voice available
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) throw new Error("No audio data");

        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const audioBuffer = await decodeAudioData(
            base64ToArrayBuffer(base64Audio),
            audioContext,
            24000,
            1
        );

        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.start();
        return "Audio playing";
    } catch (e) {
        console.error("TTS Error", e);
        return "Error playing audio";
    }
};

// --- Live API (Native Audio) ---
export const connectLiveSession = async (
    onAudioData: (buffer: AudioBuffer) => void,
    onStatusChange: (status: string) => void
) => {
    const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
    const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 16000});
    let nextStartTime = 0;
    const sources = new Set<AudioBufferSourceNode>();

    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        onStatusChange("Connecting...");

        const sessionPromise = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => {
                    onStatusChange("En Vivo");
                    // Microphone Stream
                    const source = inputAudioContext.createMediaStreamSource(stream);
                    const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob = createPcmBlob(inputData);
                        sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(inputAudioContext.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    const base64EncodedAudioString = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                    if (base64EncodedAudioString) {
                        nextStartTime = Math.max(nextStartTime, outputAudioContext.currentTime);
                        const audioBuffer = await decodeAudioData(
                            base64ToArrayBuffer(base64EncodedAudioString),
                            outputAudioContext,
                            24000, 
                            1
                        );
                        const source = outputAudioContext.createBufferSource();
                        source.buffer = audioBuffer;
                        source.connect(outputAudioContext.destination);
                        source.addEventListener('ended', () => sources.delete(source));
                        source.start(nextStartTime);
                        nextStartTime += audioBuffer.duration;
                        sources.add(source);
                        
                        onAudioData(audioBuffer); 
                    }
                },
                onclose: () => onStatusChange("Desconectado"),
                onerror: (e) => {
                    console.error(e);
                    onStatusChange("Error");
                }
            },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } }
                },
                systemInstruction: `${SYSTEM_INSTRUCTION_BASE}\n\nCONTEXTO DE DATOS ACTUALIZADO:\n${getLeagueContext()}`,
            }
        });

        return {
            disconnect: () => {
                sessionPromise.then(s => s.close());
                stream.getTracks().forEach(t => t.stop());
                outputAudioContext.close();
                inputAudioContext.close();
            }
        };

    } catch (error) {
        console.error("Live API Error:", error);
        onStatusChange("Error: Mic");
        return null;
    }
};

// --- Audio Transcription ---
export const transcribeAudio = async (base64Audio: string) => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: {
                parts: [
                    { inlineData: { mimeType: "audio/wav", data: base64Audio } },
                    { text: "Transcribe this audio strictly." }
                ]
            }
        });
        return response.text;
    } catch (e) {
        console.error(e);
        return "Error transcribing.";
    }
}